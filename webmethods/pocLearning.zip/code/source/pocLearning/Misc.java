package pocLearning;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class Misc

{
	// ---( internal utility methods )---

	final static Misc _instance = new Misc();

	static Misc _newInstance() { return new Misc(); }

	static Misc _cast(Object o) { return (Misc)o; }

	// ---( server methods )---




	public static final void sumofstrings (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sumofstrings)>> ---
		// @sigtype java 3.5
		// [i] field:0:required input1
		// [i] field:0:required input2
		// [o] field:0:required output
		// to get inputs from pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	input1 = IDataUtil.getString( pipelineCursor, "input1" );
			String	input2 = IDataUtil.getString( pipelineCursor, "input2" );
		pipelineCursor.destroy();
		
		
		//main logic ( Java service use's IData /Idata cursor to pass the data) 
		String OutputString = (input1)+(input2);
		
		
		// to send output to pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "output", OutputString );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}
}

