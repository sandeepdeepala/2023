app.service('myserv', function() {
          this.getServiceList = function () {
    return [];
}
this.getISEndpoint = function() { 
 return 'http://CathyNoelene:5555/';
}
this.getAPIList = function() { 
 return [];
}
this.getCreatedTime = function() { 
 return "27-11-2022 23:20:45 MST";
}
this.getPackageInfo = function(){
 return{"packageName":"pocWebmethodsIO","createdDate":"27-11-2022 09:36:55 MST","version":"1.0"};
}
});
